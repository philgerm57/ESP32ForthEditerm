namespace ForthEditor
{
    partial class TerminalForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mnuSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPortSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTextSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSendSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.sepSettings = new System.Windows.Forms.ToolStripSeparator();
            this.mnuSuppressEcho = new System.Windows.Forms.ToolStripMenuItem();
            this.topPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSendFile = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtTerminal = new System.Windows.Forms.RichTextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.ctxTerminal = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ctxTermCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxTermCopyAll = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxTermSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxTermPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxTermClear = new System.Windows.Forms.ToolStripMenuItem();
            this.sepTerm1 = new System.Windows.Forms.ToolStripSeparator();
            this.sepTerm2 = new System.Windows.Forms.ToolStripSeparator();
            this.ctxTerminal.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.topPanel.SuspendLayout();
            this.SuspendLayout();
            // menuStrip
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuSettings });
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(834, 24);
            this.menuStrip.TabIndex = 0;
            // mnuSettings
            this.mnuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuPortSettings, this.mnuTextSettings, this.mnuSendSettings, this.sepSettings, this.mnuSuppressEcho });
            this.mnuSettings.Name = "mnuSettings";
            this.mnuSettings.Text = "&Paramètres";
            // mnuPortSettings
            this.mnuPortSettings.Name = "mnuPortSettings";
            this.mnuPortSettings.Text = "&Port série (vitesse, bits, parité, stop)…";
            this.mnuPortSettings.Click += new System.EventHandler(this.mnuPortSettings_Click);
            // mnuTextSettings
            this.mnuTextSettings.Name = "mnuTextSettings";
            this.mnuTextSettings.Text = "&Texte et couleurs (encodage, fin de ligne)…";
            this.mnuTextSettings.Click += new System.EventHandler(this.mnuTextSettings_Click);
            // mnuSendSettings
            this.mnuSendSettings.Name = "mnuSendSettings";
            this.mnuSendSettings.Text = "&Envoi de l'éditeur (pause, invite)…";
            this.mnuSendSettings.Click += new System.EventHandler(this.mnuSendSettings_Click);
            // sepSettings
            this.sepSettings.Name = "sepSettings";
            // mnuSuppressEcho
            this.mnuSuppressEcho.CheckOnClick = true;
            this.mnuSuppressEcho.Name = "mnuSuppressEcho";
            this.mnuSuppressEcho.Text = "Supprimer l'é&cho de la cible";
            this.mnuSuppressEcho.ToolTipText = "Masque le texte que la cible renvoie après chaque ligne envoyée (écho distant)";
            this.mnuSuppressEcho.Click += new System.EventHandler(this.mnuSuppressEcho_Click);
            // topPanel
            this.topPanel.AutoSize = true;
            this.topPanel.Controls.Add(this.btnOpen);
            this.topPanel.Controls.Add(this.btnClose);
            this.topPanel.Controls.Add(this.btnSendFile);
            this.topPanel.Controls.Add(this.btnClear);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 24);
            this.topPanel.Name = "topPanel";
            this.topPanel.Padding = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.topPanel.Size = new System.Drawing.Size(834, 44);
            this.topPanel.TabIndex = 1;
            // btnOpen
            this.btnOpen.AutoSize = true;
            this.btnOpen.Margin = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.btnOpen.MinimumSize = new System.Drawing.Size(90, 30);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.TabIndex = 0;
            this.btnOpen.Text = "Ouvrir";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.BtnOpen_Click);
            // btnClose
            this.btnClose.AutoSize = true;
            this.btnClose.Margin = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.btnClose.MinimumSize = new System.Drawing.Size(90, 30);
            this.btnClose.Name = "btnClose";
            this.btnClose.TabIndex = 1;
            this.btnClose.Text = "Fermer";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.BtnClose_Click);
            // btnSendFile
            this.btnSendFile.AutoSize = true;
            this.btnSendFile.Margin = new System.Windows.Forms.Padding(24, 3, 3, 3);
            this.btnSendFile.MinimumSize = new System.Drawing.Size(130, 30);
            this.btnSendFile.Name = "btnSendFile";
            this.btnSendFile.TabIndex = 2;
            this.btnSendFile.Text = "Envoyer l'éditeur";
            this.btnSendFile.UseVisualStyleBackColor = true;
            this.btnSendFile.Click += new System.EventHandler(this.BtnSendFile_Click);
            // btnClear
            this.btnClear.AutoSize = true;
            this.btnClear.Margin = new System.Windows.Forms.Padding(24, 3, 3, 3);
            this.btnClear.MinimumSize = new System.Drawing.Size(130, 30);
            this.btnClear.Name = "btnClear";
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Effacer l'éditeur";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.BtnClear_Click);
            // ctxTerminal
            this.ctxTerminal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.ctxTermCopy, this.ctxTermCopyAll, this.ctxTermSelectAll, this.sepTerm1, this.ctxTermPaste, this.sepTerm2, this.ctxTermClear });
            this.ctxTerminal.Name = "ctxTerminal";
            this.ctxTerminal.Size = new System.Drawing.Size(200, 148);
            this.ctxTerminal.Opening += new System.ComponentModel.CancelEventHandler(this.ctxTerminal_Opening);
            // ctxTermCopy
            this.ctxTermCopy.Name = "ctxTermCopy";
            this.ctxTermCopy.Text = "Copier";
            this.ctxTermCopy.ShortcutKeyDisplayString = "Ctrl+C";
            this.ctxTermCopy.Click += new System.EventHandler(this.ctxTermCopy_Click);
            // ctxTermCopyAll
            this.ctxTermCopyAll.Name = "ctxTermCopyAll";
            this.ctxTermCopyAll.Text = "Copier tout";
            this.ctxTermCopyAll.Click += new System.EventHandler(this.ctxTermCopyAll_Click);
            // ctxTermSelectAll
            this.ctxTermSelectAll.Name = "ctxTermSelectAll";
            this.ctxTermSelectAll.Text = "Tout sélectionner";
            this.ctxTermSelectAll.ShortcutKeyDisplayString = "Ctrl+A";
            this.ctxTermSelectAll.Click += new System.EventHandler(this.ctxTermSelectAll_Click);
            // ctxTermPaste
            this.ctxTermPaste.Name = "ctxTermPaste";
            this.ctxTermPaste.Text = "Coller";
            this.ctxTermPaste.ShortcutKeyDisplayString = "Ctrl+V";
            this.ctxTermPaste.Click += new System.EventHandler(this.ctxTermPaste_Click);
            // ctxTermClear
            this.ctxTermClear.Name = "ctxTermClear";
            this.ctxTermClear.Text = "Effacer l'affichage";
            this.ctxTermClear.Click += new System.EventHandler(this.ctxTermClear_Click);
            // sepTerm1
            this.sepTerm1.Name = "sepTerm1";
            // sepTerm2
            this.sepTerm2.Name = "sepTerm2";
            // txtTerminal
            this.txtTerminal.AcceptsTab = true;
            this.txtTerminal.ContextMenuStrip = this.ctxTerminal;
            this.txtTerminal.BackColor = System.Drawing.Color.Black;
            this.txtTerminal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTerminal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTerminal.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtTerminal.ForeColor = System.Drawing.Color.LimeGreen;
            this.txtTerminal.Name = "txtTerminal";
            this.txtTerminal.TabIndex = 4;
            this.txtTerminal.Text = "";
            this.txtTerminal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtTerminal_KeyDown);
            // lblStatus
            this.lblStatus.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.lblStatus.Size = new System.Drawing.Size(834, 26);
            this.lblStatus.TabIndex = 5;
            this.lblStatus.Text = "Déconnecté";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // TerminalForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 548);
            this.Controls.Add(this.txtTerminal);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.MinimumSize = new System.Drawing.Size(600, 400);
            this.Name = "TerminalForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Terminal série";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TerminalForm_FormClosing);
            this.ctxTerminal.ResumeLayout(false);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem mnuSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuPortSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuTextSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuSendSettings;
        private System.Windows.Forms.ToolStripSeparator sepSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuSuppressEcho;
        private System.Windows.Forms.FlowLayoutPanel topPanel;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSendFile;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.RichTextBox txtTerminal;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ContextMenuStrip ctxTerminal;
        private System.Windows.Forms.ToolStripMenuItem ctxTermCopy;
        private System.Windows.Forms.ToolStripMenuItem ctxTermCopyAll;
        private System.Windows.Forms.ToolStripMenuItem ctxTermSelectAll;
        private System.Windows.Forms.ToolStripMenuItem ctxTermPaste;
        private System.Windows.Forms.ToolStripMenuItem ctxTermClear;
        private System.Windows.Forms.ToolStripSeparator sepTerm1;
        private System.Windows.Forms.ToolStripSeparator sepTerm2;
    }
}
