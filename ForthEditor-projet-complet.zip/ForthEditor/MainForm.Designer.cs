namespace ForthEditor
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.ctxEditor = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.splitOuter = new System.Windows.Forms.SplitContainer();
            this.splitInner = new System.Windows.Forms.SplitContainer();
            this.tabs = new System.Windows.Forms.TabControl();
            this.pnlOutline = new System.Windows.Forms.Panel();
            this.lblOutline = new System.Windows.Forms.Label();
            this.txtOutlineFilter = new System.Windows.Forms.TextBox();
            this.lstOutline = new System.Windows.Forms.ListBox();
            this.pnlOutput = new System.Windows.Forms.Panel();
            this.pnlOutputBar = new System.Windows.Forms.Panel();
            this.lblOutputTitle = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnClearOutput = new System.Windows.Forms.Button();
            this.btnHideOutput = new System.Windows.Forms.Button();
            this.rtbOutput = new System.Windows.Forms.RichTextBox();
            this.txtStdin = new System.Windows.Forms.TextBox();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuView = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRunMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSettingsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToolsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTerminal = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTheme = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFold = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuNew = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRecent = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSave = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQuit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUndo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRedo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCut = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFind = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFindNext = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFindPrev = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReplace = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGoTo = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuReloadSyntax = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEditSyntax = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThemeDark = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuThemeLight = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuZoomIn = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuZoomOut = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuZoomReset = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShowOutline = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShowOutput = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFoldToggle = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFoldAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUnfoldAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRestoreSession = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRun = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStop = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearOutput = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuForthSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAutoComplete = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxCut = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxCopy = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxPaste = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxSelectAll = new System.Windows.Forms.ToolStripMenuItem();
            this.sepFile1 = new System.Windows.Forms.ToolStripSeparator();
            this.sepFile2 = new System.Windows.Forms.ToolStripSeparator();
            this.sepFile3 = new System.Windows.Forms.ToolStripSeparator();
            this.sepFile4 = new System.Windows.Forms.ToolStripSeparator();
            this.sepEdit1 = new System.Windows.Forms.ToolStripSeparator();
            this.sepEdit2 = new System.Windows.Forms.ToolStripSeparator();
            this.sepEdit3 = new System.Windows.Forms.ToolStripSeparator();
            this.sepView1 = new System.Windows.Forms.ToolStripSeparator();
            this.sepView2 = new System.Windows.Forms.ToolStripSeparator();
            this.sepView3 = new System.Windows.Forms.ToolStripSeparator();
            this.sepCtx = new System.Windows.Forms.ToolStripSeparator();
            this.lblSpring = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblPos = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblSel = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblLines = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblEol = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.splitLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitOuter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitInner)).BeginInit();
            this.splitLeft.Panel1.SuspendLayout();
            this.splitLeft.Panel2.SuspendLayout();
            this.splitLeft.SuspendLayout();
            this.pnlProject.SuspendLayout();
            this.pnlProjectBar.SuspendLayout();
            this.ctxProject.SuspendLayout();
            this.splitOuter.Panel1.SuspendLayout();
            this.splitOuter.Panel2.SuspendLayout();
            this.splitInner.Panel1.SuspendLayout();
            this.splitInner.Panel2.SuspendLayout();
            this.splitOuter.SuspendLayout();
            this.splitInner.SuspendLayout();
            this.pnlOutline.SuspendLayout();
            this.pnlOutput.SuspendLayout();
            this.pnlOutputBar.SuspendLayout();
            this.splitLeft = new System.Windows.Forms.SplitContainer();
            this.pnlProject = new System.Windows.Forms.Panel();
            this.lblProject = new System.Windows.Forms.Label();
            this.pnlProjectBar = new System.Windows.Forms.Panel();
            this.cboProjectFolder = new System.Windows.Forms.ComboBox();
            this.btnProjectBrowse = new System.Windows.Forms.Button();
            this.cboProjectFilter = new System.Windows.Forms.ComboBox();
            this.txtProjectFilter = new System.Windows.Forms.TextBox();
            this.tvProject = new System.Windows.Forms.TreeView();
            this.ctxProject = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ctxProjOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxProjNewFile = new System.Windows.Forms.ToolStripMenuItem();
            this.sepProj = new System.Windows.Forms.ToolStripSeparator();
            this.ctxProjExplorer = new System.Windows.Forms.ToolStripMenuItem();
            this.ctxProjRefresh = new System.Windows.Forms.ToolStripMenuItem();
            this.chkOutlineDefsOnly = new System.Windows.Forms.CheckBox();
            this.mnuOpenFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShowProject = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOpenSyntaxFolder = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.ctxEditor.SuspendLayout();
            this.SuspendLayout();
            // menuStrip
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuFile, this.mnuEdit, this.mnuView, this.mnuRunMenu, this.mnuToolsMenu, this.mnuSettingsMenu });
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1100, 24);
            this.menuStrip.TabIndex = 0;
            // mnuFile
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuNew, this.mnuOpen, this.mnuOpenFolder, this.mnuRecent, this.sepFile1, this.mnuSave, this.mnuSaveAs, this.sepFile2, this.mnuPrint, this.sepFile3, this.mnuClose, this.mnuDelete, this.sepFile4, this.mnuQuit });
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Text = "&Fichier";
            // mnuEdit
            this.mnuEdit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuUndo, this.mnuRedo, this.sepEdit1, this.mnuCut, this.mnuCopy, this.mnuPaste, this.mnuSelectAll, this.sepEdit2, this.mnuFind, this.mnuFindNext, this.mnuFindPrev, this.mnuReplace, this.sepEdit3, this.mnuGoTo });
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Text = "&Édition";
            // mnuView
            this.mnuView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuReloadSyntax, this.mnuEditSyntax, this.mnuOpenSyntaxFolder, this.sepView1, this.mnuTheme, this.mnuZoomIn, this.mnuZoomOut, this.mnuZoomReset, this.sepView2, this.mnuShowProject, this.mnuShowOutline, this.mnuShowOutput, this.mnuFold, this.sepView3, this.mnuRestoreSession });
            this.mnuView.Name = "mnuView";
            this.mnuView.Text = "&Affichage";
            // mnuRunMenu
            this.mnuRunMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuRun, this.mnuStop, this.mnuClearOutput });
            this.mnuRunMenu.Name = "mnuRunMenu";
            this.mnuRunMenu.Text = "&Exécution";
            // mnuToolsMenu
            this.mnuToolsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuTerminal });
            this.mnuToolsMenu.Name = "mnuToolsMenu";
            this.mnuToolsMenu.Text = "&Outils";
            // mnuTerminal
            this.mnuTerminal.Name = "mnuTerminal";
            this.mnuTerminal.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.T)));
            this.mnuTerminal.Text = "Terminal &série…";
            this.mnuTerminal.Click += new System.EventHandler(this.mnuTerminal_Click);
            // mnuSettingsMenu
            this.mnuSettingsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuForthSettings, this.mnuAutoComplete });
            this.mnuSettingsMenu.Name = "mnuSettingsMenu";
            this.mnuSettingsMenu.Text = "&Paramètres";
            // mnuTheme
            this.mnuTheme.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuThemeDark, this.mnuThemeLight });
            this.mnuTheme.Name = "mnuTheme";
            this.mnuTheme.Text = "&Thème";
            // mnuFold
            this.mnuFold.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.mnuFoldToggle, this.mnuFoldAll, this.mnuUnfoldAll });
            this.mnuFold.Name = "mnuFold";
            this.mnuFold.Text = "&Repli du code";
            // mnuNew
            this.mnuNew.Name = "mnuNew";
            this.mnuNew.Text = "&Nouveau";
            this.mnuNew.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N));
            this.mnuNew.Click += new System.EventHandler(this.mnuNew_Click);
            // mnuOpen
            this.mnuOpen.Name = "mnuOpen";
            this.mnuOpen.Text = "&Ouvrir dans un nouvel onglet…";
            this.mnuOpen.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O));
            this.mnuOpen.Click += new System.EventHandler(this.mnuOpen_Click);
            // mnuRecent
            this.mnuRecent.Name = "mnuRecent";
            this.mnuRecent.Text = "Fichiers &récents";
            // mnuSave
            this.mnuSave.Name = "mnuSave";
            this.mnuSave.Text = "&Enregistrer";
            this.mnuSave.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S));
            this.mnuSave.Click += new System.EventHandler(this.mnuSave_Click);
            // mnuSaveAs
            this.mnuSaveAs.Name = "mnuSaveAs";
            this.mnuSaveAs.Text = "Enregistrer &sous…";
            this.mnuSaveAs.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.S));
            this.mnuSaveAs.Click += new System.EventHandler(this.mnuSaveAs_Click);
            // mnuPrint
            this.mnuPrint.Name = "mnuPrint";
            this.mnuPrint.Text = "&Imprimer…";
            this.mnuPrint.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P));
            this.mnuPrint.Click += new System.EventHandler(this.mnuPrint_Click);
            // mnuClose
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Text = "&Fermer l'onglet";
            this.mnuClose.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W));
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // mnuDelete
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Text = "&Détruire le fichier de la page courante";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // mnuQuit
            this.mnuQuit.Name = "mnuQuit";
            this.mnuQuit.Text = "&Quitter";
            this.mnuQuit.ShortcutKeyDisplayString = "Alt+F4";
            this.mnuQuit.Click += new System.EventHandler(this.mnuQuit_Click);
            // mnuUndo
            this.mnuUndo.Name = "mnuUndo";
            this.mnuUndo.Text = "&Annuler";
            this.mnuUndo.Click += new System.EventHandler(this.Undo_Click);
            // mnuRedo
            this.mnuRedo.Name = "mnuRedo";
            this.mnuRedo.Text = "&Rétablir";
            this.mnuRedo.Click += new System.EventHandler(this.Redo_Click);
            // mnuCut
            this.mnuCut.Name = "mnuCut";
            this.mnuCut.Text = "Co&uper";
            this.mnuCut.Click += new System.EventHandler(this.Cut_Click);
            // mnuCopy
            this.mnuCopy.Name = "mnuCopy";
            this.mnuCopy.Text = "&Copier";
            this.mnuCopy.Click += new System.EventHandler(this.Copy_Click);
            // mnuPaste
            this.mnuPaste.Name = "mnuPaste";
            this.mnuPaste.Text = "&Coller";
            this.mnuPaste.Click += new System.EventHandler(this.Paste_Click);
            // mnuSelectAll
            this.mnuSelectAll.Name = "mnuSelectAll";
            this.mnuSelectAll.Text = "Tout &sélectionner";
            this.mnuSelectAll.Click += new System.EventHandler(this.SelectAll_Click);
            // mnuFind
            this.mnuFind.Name = "mnuFind";
            this.mnuFind.Text = "&Rechercher…";
            this.mnuFind.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F));
            this.mnuFind.Click += new System.EventHandler(this.mnuFind_Click);
            // mnuFindNext
            this.mnuFindNext.Name = "mnuFindNext";
            this.mnuFindNext.Text = "Occurrence &suivante";
            this.mnuFindNext.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.F3));
            this.mnuFindNext.Click += new System.EventHandler(this.mnuFindNext_Click);
            // mnuFindPrev
            this.mnuFindPrev.Name = "mnuFindPrev";
            this.mnuFindPrev.Text = "Occurrence &précédente";
            this.mnuFindPrev.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F3));
            this.mnuFindPrev.Click += new System.EventHandler(this.mnuFindPrev_Click);
            // mnuReplace
            this.mnuReplace.Name = "mnuReplace";
            this.mnuReplace.Text = "Re&mplacer…";
            this.mnuReplace.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.H));
            this.mnuReplace.Click += new System.EventHandler(this.mnuReplace_Click);
            // mnuGoTo
            this.mnuGoTo.Name = "mnuGoTo";
            this.mnuGoTo.Text = "Aller à la &ligne…";
            this.mnuGoTo.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G));
            this.mnuGoTo.Click += new System.EventHandler(this.mnuGoTo_Click);
            // mnuReloadSyntax
            this.mnuReloadSyntax.Name = "mnuReloadSyntax";
            this.mnuReloadSyntax.Text = "&Recharger la coloration (syntax.json)";
            this.mnuReloadSyntax.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F5));
            this.mnuReloadSyntax.Click += new System.EventHandler(this.mnuReloadSyntax_Click);
            // mnuEditSyntax
            this.mnuEditSyntax.Name = "mnuEditSyntax";
            this.mnuEditSyntax.Text = "&Modifier syntax.json";
            this.mnuEditSyntax.Click += new System.EventHandler(this.mnuEditSyntax_Click);
            // mnuThemeDark
            this.mnuThemeDark.Name = "mnuThemeDark";
            this.mnuThemeDark.Text = "&Sombre";
            this.mnuThemeDark.Click += new System.EventHandler(this.mnuThemeDark_Click);
            // mnuThemeLight
            this.mnuThemeLight.Name = "mnuThemeLight";
            this.mnuThemeLight.Text = "C&lair";
            this.mnuThemeLight.Click += new System.EventHandler(this.mnuThemeLight_Click);
            // mnuZoomIn
            this.mnuZoomIn.Name = "mnuZoomIn";
            this.mnuZoomIn.Text = "&Agrandir la police";
            this.mnuZoomIn.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Oemplus));
            this.mnuZoomIn.ShortcutKeyDisplayString = "Ctrl++";
            this.mnuZoomIn.Click += new System.EventHandler(this.mnuZoomIn_Click);
            // mnuZoomOut
            this.mnuZoomOut.Name = "mnuZoomOut";
            this.mnuZoomOut.Text = "&Diminuer la police";
            this.mnuZoomOut.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.OemMinus));
            this.mnuZoomOut.ShortcutKeyDisplayString = "Ctrl+-";
            this.mnuZoomOut.Click += new System.EventHandler(this.mnuZoomOut_Click);
            // mnuZoomReset
            this.mnuZoomReset.Name = "mnuZoomReset";
            this.mnuZoomReset.Text = "Taille &normale";
            this.mnuZoomReset.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D0));
            this.mnuZoomReset.Click += new System.EventHandler(this.mnuZoomReset_Click);
            // mnuShowOutline
            this.mnuShowOutline.Name = "mnuShowOutline";
            this.mnuShowOutline.Text = "Plan des &définitions";
            this.mnuShowOutline.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.F7));
            this.mnuShowOutline.Click += new System.EventHandler(this.mnuShowOutline_Click);
            // mnuShowOutput
            this.mnuShowOutput.Name = "mnuShowOutput";
            this.mnuShowOutput.Text = "Panneau de &sortie";
            this.mnuShowOutput.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.F6));
            this.mnuShowOutput.Click += new System.EventHandler(this.mnuShowOutput_Click);
            // mnuFoldToggle
            this.mnuFoldToggle.Name = "mnuFoldToggle";
            this.mnuFoldToggle.Text = "&Replier / déplier le bloc courant";
            this.mnuFoldToggle.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F));
            this.mnuFoldToggle.Click += new System.EventHandler(this.mnuFoldToggle_Click);
            // mnuFoldAll
            this.mnuFoldAll.Name = "mnuFoldAll";
            this.mnuFoldAll.Text = "Tout &replier";
            this.mnuFoldAll.Click += new System.EventHandler(this.mnuFoldAll_Click);
            // mnuUnfoldAll
            this.mnuUnfoldAll.Name = "mnuUnfoldAll";
            this.mnuUnfoldAll.Text = "Tout &déplier";
            this.mnuUnfoldAll.Click += new System.EventHandler(this.mnuUnfoldAll_Click);
            // mnuRestoreSession
            this.mnuRestoreSession.Name = "mnuRestoreSession";
            this.mnuRestoreSession.Text = "Restaurer la &session au démarrage";
            this.mnuRestoreSession.CheckOnClick = true;
            this.mnuRestoreSession.Click += new System.EventHandler(this.mnuRestoreSession_Click);
            // mnuRun
            this.mnuRun.Name = "mnuRun";
            this.mnuRun.Text = "&Exécuter le fichier";
            this.mnuRun.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.F5));
            this.mnuRun.Click += new System.EventHandler(this.mnuRun_Click);
            // mnuStop
            this.mnuStop.Name = "mnuStop";
            this.mnuStop.Text = "&Arrêter";
            this.mnuStop.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.F5));
            this.mnuStop.Click += new System.EventHandler(this.mnuStop_Click);
            // mnuClearOutput
            this.mnuClearOutput.Name = "mnuClearOutput";
            this.mnuClearOutput.Text = "E&ffacer la sortie";
            this.mnuClearOutput.Click += new System.EventHandler(this.mnuClearOutput_Click);
            // mnuForthSettings
            this.mnuForthSettings.Name = "mnuForthSettings";
            this.mnuForthSettings.Text = "Interpréteur &Forth…";
            this.mnuForthSettings.Click += new System.EventHandler(this.mnuForthSettings_Click);
            // mnuAutoComplete
            this.mnuAutoComplete.Name = "mnuAutoComplete";
            this.mnuAutoComplete.Text = "&Complétion automatique";
            this.mnuAutoComplete.CheckOnClick = true;
            this.mnuAutoComplete.Checked = true;
            this.mnuAutoComplete.Click += new System.EventHandler(this.mnuAutoComplete_Click);
            // mnuOpenFolder
            this.mnuOpenFolder.Name = "mnuOpenFolder";
            this.mnuOpenFolder.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.O));
            this.mnuOpenFolder.Text = "Ouvrir un &dossier (projet)…";
            this.mnuOpenFolder.Click += new System.EventHandler(this.mnuOpenFolder_Click);
            // mnuShowProject
            this.mnuShowProject.Name = "mnuShowProject";
            this.mnuShowProject.ShortcutKeys = ((System.Windows.Forms.Keys)(System.Windows.Forms.Keys.F8));
            this.mnuShowProject.Text = "&Projet (dossier)";
            this.mnuShowProject.Click += new System.EventHandler(this.mnuShowProject_Click);
            // mnuOpenSyntaxFolder
            this.mnuOpenSyntaxFolder.Name = "mnuOpenSyntaxFolder";
            this.mnuOpenSyntaxFolder.Text = "Ouvrir le dossier des &syntaxes";
            this.mnuOpenSyntaxFolder.Click += new System.EventHandler(this.mnuOpenSyntaxFolder_Click);
            // sepFile1
            this.sepFile1.Name = "sepFile1";
            // sepFile2
            this.sepFile2.Name = "sepFile2";
            // sepFile3
            this.sepFile3.Name = "sepFile3";
            // sepFile4
            this.sepFile4.Name = "sepFile4";
            // sepEdit1
            this.sepEdit1.Name = "sepEdit1";
            // sepEdit2
            this.sepEdit2.Name = "sepEdit2";
            // sepEdit3
            this.sepEdit3.Name = "sepEdit3";
            // sepView1
            this.sepView1.Name = "sepView1";
            // sepView2
            this.sepView2.Name = "sepView2";
            // sepView3
            this.sepView3.Name = "sepView3";
            // sepCtx
            this.sepCtx.Name = "sepCtx";
            // ctxEditor
            this.ctxEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.ctxCut, this.ctxCopy, this.ctxPaste, this.sepCtx, this.ctxSelectAll });
            this.ctxEditor.Name = "ctxEditor";
            this.ctxEditor.Size = new System.Drawing.Size(181, 98);
            this.ctxEditor.Opening += new System.ComponentModel.CancelEventHandler(this.ctxEditor_Opening);
            // ctxCut
            this.ctxCut.Name = "ctxCut";
            this.ctxCut.Text = "Couper";
            this.ctxCut.Click += new System.EventHandler(this.Cut_Click);
            // ctxCopy
            this.ctxCopy.Name = "ctxCopy";
            this.ctxCopy.Text = "Copier";
            this.ctxCopy.Click += new System.EventHandler(this.Copy_Click);
            // ctxPaste
            this.ctxPaste.Name = "ctxPaste";
            this.ctxPaste.Text = "Coller";
            this.ctxPaste.Click += new System.EventHandler(this.Paste_Click);
            // ctxSelectAll
            this.ctxSelectAll.Name = "ctxSelectAll";
            this.ctxSelectAll.Text = "Tout sélectionner";
            this.ctxSelectAll.Click += new System.EventHandler(this.SelectAll_Click);
            // splitLeft
            this.splitLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitLeft.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitLeft.Location = new System.Drawing.Point(0, 24);
            this.splitLeft.Name = "splitLeft";
            this.splitLeft.Panel1.Controls.Add(this.pnlProject);
            this.splitLeft.Panel1MinSize = 120;
            this.splitLeft.Panel2.Controls.Add(this.splitOuter);
            this.splitLeft.Size = new System.Drawing.Size(1100, 674);
            this.splitLeft.SplitterDistance = 220;
            this.splitLeft.TabIndex = 1;
            // splitOuter
            this.splitOuter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitOuter.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitOuter.Location = new System.Drawing.Point(0, 0);
            this.splitOuter.Name = "splitOuter";
            this.splitOuter.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.splitOuter.Panel1.Controls.Add(this.splitInner);
            this.splitOuter.Panel2.Controls.Add(this.pnlOutput);
            this.splitOuter.Size = new System.Drawing.Size(876, 674);
            this.splitOuter.SplitterDistance = 480;
            this.splitOuter.TabIndex = 0;
            // splitInner
            this.splitInner.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitInner.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitInner.Name = "splitInner";
            this.splitInner.Panel1.Controls.Add(this.tabs);
            this.splitInner.Panel2.Controls.Add(this.pnlOutline);
            this.splitInner.Panel2MinSize = 120;
            this.splitInner.Size = new System.Drawing.Size(1100, 480);
            this.splitInner.SplitterDistance = 860;
            this.splitInner.TabIndex = 0;
            // pnlProject
            this.pnlProject.Controls.Add(this.tvProject);
            this.pnlProject.Controls.Add(this.txtProjectFilter);
            this.pnlProject.Controls.Add(this.cboProjectFilter);
            this.pnlProject.Controls.Add(this.pnlProjectBar);
            this.pnlProject.Controls.Add(this.lblProject);
            this.pnlProject.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProject.Name = "pnlProject";
            this.pnlProject.Size = new System.Drawing.Size(220, 674);
            this.pnlProject.TabIndex = 0;
            // lblProject
            this.lblProject.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(220, 22);
            this.lblProject.TabIndex = 0;
            this.lblProject.Text = " Projet (dossier)";
            this.lblProject.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // pnlProjectBar
            this.pnlProjectBar.Controls.Add(this.cboProjectFolder);
            this.pnlProjectBar.Controls.Add(this.btnProjectBrowse);
            this.pnlProjectBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlProjectBar.Name = "pnlProjectBar";
            this.pnlProjectBar.Size = new System.Drawing.Size(220, 27);
            this.pnlProjectBar.TabIndex = 1;
            // cboProjectFolder
            this.cboProjectFolder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cboProjectFolder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProjectFolder.FormattingEnabled = true;
            this.cboProjectFolder.Name = "cboProjectFolder";
            this.cboProjectFolder.Size = new System.Drawing.Size(186, 23);
            this.cboProjectFolder.TabIndex = 0;
            this.cboProjectFolder.SelectionChangeCommitted += new System.EventHandler(this.cboProjectFolder_SelectionChangeCommitted);
            // btnProjectBrowse
            this.btnProjectBrowse.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnProjectBrowse.Name = "btnProjectBrowse";
            this.btnProjectBrowse.Size = new System.Drawing.Size(34, 27);
            this.btnProjectBrowse.TabIndex = 1;
            this.btnProjectBrowse.Text = "…";
            this.btnProjectBrowse.UseVisualStyleBackColor = true;
            this.btnProjectBrowse.Click += new System.EventHandler(this.btnProjectBrowse_Click);
            // cboProjectFilter
            this.cboProjectFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.cboProjectFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProjectFilter.FormattingEnabled = true;
            this.cboProjectFilter.Name = "cboProjectFilter";
            this.cboProjectFilter.Size = new System.Drawing.Size(220, 23);
            this.cboProjectFilter.TabIndex = 2;
            this.cboProjectFilter.SelectionChangeCommitted += new System.EventHandler(this.cboProjectFilter_SelectionChangeCommitted);
            // txtProjectFilter
            this.txtProjectFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtProjectFilter.Name = "txtProjectFilter";
            this.txtProjectFilter.PlaceholderText = "Filtrer par nom…";
            this.txtProjectFilter.Size = new System.Drawing.Size(220, 23);
            this.txtProjectFilter.TabIndex = 3;
            this.txtProjectFilter.TextChanged += new System.EventHandler(this.txtProjectFilter_TextChanged);
            // tvProject
            this.tvProject.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tvProject.ContextMenuStrip = this.ctxProject;
            this.tvProject.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvProject.HideSelection = false;
            this.tvProject.Name = "tvProject";
            this.tvProject.Size = new System.Drawing.Size(220, 575);
            this.tvProject.TabIndex = 4;
            this.tvProject.BeforeExpand += new System.Windows.Forms.TreeViewCancelEventHandler(this.tvProject_BeforeExpand);
            this.tvProject.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvProject_NodeMouseDoubleClick);
            this.tvProject.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tvProject_KeyDown);
            this.tvProject.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tvProject_MouseDown);
            // ctxProject
            this.ctxProject.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.ctxProjOpen, this.ctxProjNewFile, this.sepProj, this.ctxProjExplorer, this.ctxProjRefresh });
            this.ctxProject.Name = "ctxProject";
            this.ctxProject.Size = new System.Drawing.Size(210, 98);
            this.ctxProject.Opening += new System.ComponentModel.CancelEventHandler(this.ctxProject_Opening);
            // ctxProjOpen
            this.ctxProjOpen.Name = "ctxProjOpen";
            this.ctxProjOpen.Text = "Ouvrir";
            this.ctxProjOpen.Click += new System.EventHandler(this.ctxProjOpen_Click);
            // ctxProjNewFile
            this.ctxProjNewFile.Name = "ctxProjNewFile";
            this.ctxProjNewFile.Text = "Nouveau fichier…";
            this.ctxProjNewFile.Click += new System.EventHandler(this.ctxProjNewFile_Click);
            // sepProj
            this.sepProj.Name = "sepProj";
            // ctxProjExplorer
            this.ctxProjExplorer.Name = "ctxProjExplorer";
            this.ctxProjExplorer.Text = "Afficher dans l'Explorateur";
            this.ctxProjExplorer.Click += new System.EventHandler(this.ctxProjExplorer_Click);
            // ctxProjRefresh
            this.ctxProjRefresh.Name = "ctxProjRefresh";
            this.ctxProjRefresh.Text = "Actualiser";
            this.ctxProjRefresh.Click += new System.EventHandler(this.ctxProjRefresh_Click);
            // chkOutlineDefsOnly
            this.chkOutlineDefsOnly.Dock = System.Windows.Forms.DockStyle.Top;
            this.chkOutlineDefsOnly.Name = "chkOutlineDefsOnly";
            this.chkOutlineDefsOnly.Padding = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this.chkOutlineDefsOnly.Size = new System.Drawing.Size(236, 22);
            this.chkOutlineDefsOnly.TabIndex = 3;
            this.chkOutlineDefsOnly.Text = "Seulement les « : »";
            this.chkOutlineDefsOnly.UseVisualStyleBackColor = true;
            this.chkOutlineDefsOnly.CheckedChanged += new System.EventHandler(this.chkOutlineDefsOnly_CheckedChanged);
            // tabs
            this.tabs.AllowDrop = true;
            this.tabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabs.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabs.ItemSize = new System.Drawing.Size(180, 26);
            this.tabs.Location = new System.Drawing.Point(0, 0);
            this.tabs.Name = "tabs";
            this.tabs.Padding = new System.Drawing.Point(12, 4);
            this.tabs.ShowToolTips = true;
            this.tabs.Size = new System.Drawing.Size(860, 480);
            this.tabs.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabs.TabIndex = 0;
            this.tabs.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabs_DrawItem);
            this.tabs.SelectedIndexChanged += new System.EventHandler(this.tabs_SelectedIndexChanged);
            this.tabs.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.tabs_MouseDoubleClick);
            this.tabs.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabs_MouseDown);
            this.tabs.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.tabs.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            // pnlOutline
            this.pnlOutline.Controls.Add(this.lstOutline);
            this.pnlOutline.Controls.Add(this.txtOutlineFilter);
            this.pnlOutline.Controls.Add(this.chkOutlineDefsOnly);
            this.pnlOutline.Controls.Add(this.lblOutline);
            this.pnlOutline.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOutline.Name = "pnlOutline";
            this.pnlOutline.Size = new System.Drawing.Size(236, 480);
            this.pnlOutline.TabIndex = 0;
            // lblOutline
            this.lblOutline.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblOutline.Name = "lblOutline";
            this.lblOutline.Size = new System.Drawing.Size(236, 22);
            this.lblOutline.TabIndex = 0;
            this.lblOutline.Text = " Définitions";
            this.lblOutline.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // txtOutlineFilter
            this.txtOutlineFilter.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtOutlineFilter.Name = "txtOutlineFilter";
            this.txtOutlineFilter.PlaceholderText = "Filtrer…";
            this.txtOutlineFilter.Size = new System.Drawing.Size(236, 23);
            this.txtOutlineFilter.TabIndex = 1;
            this.txtOutlineFilter.TextChanged += new System.EventHandler(this.txtOutlineFilter_TextChanged);
            // lstOutline
            this.lstOutline.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstOutline.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstOutline.FormattingEnabled = true;
            this.lstOutline.HorizontalScrollbar = true;
            this.lstOutline.IntegralHeight = false;
            this.lstOutline.Name = "lstOutline";
            this.lstOutline.Size = new System.Drawing.Size(236, 435);
            this.lstOutline.TabIndex = 2;
            this.lstOutline.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lstOutline_KeyDown);
            this.lstOutline.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lstOutline_MouseClick);
            // pnlOutput
            this.pnlOutput.Controls.Add(this.rtbOutput);
            this.pnlOutput.Controls.Add(this.txtStdin);
            this.pnlOutput.Controls.Add(this.pnlOutputBar);
            this.pnlOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOutput.Name = "pnlOutput";
            this.pnlOutput.Size = new System.Drawing.Size(1100, 190);
            this.pnlOutput.TabIndex = 0;
            // pnlOutputBar
            this.pnlOutputBar.Controls.Add(this.btnHideOutput);
            this.pnlOutputBar.Controls.Add(this.lblOutputTitle);
            this.pnlOutputBar.Controls.Add(this.btnClearOutput);
            this.pnlOutputBar.Controls.Add(this.btnStop);
            this.pnlOutputBar.Controls.Add(this.btnRun);
            this.pnlOutputBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlOutputBar.Name = "pnlOutputBar";
            this.pnlOutputBar.Size = new System.Drawing.Size(1100, 30);
            this.pnlOutputBar.TabIndex = 0;
            // btnRun
            this.btnRun.Location = new System.Drawing.Point(4, 3);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(100, 24);
            this.btnRun.Text = "▶ Exécuter";
            this.btnRun.Click += new System.EventHandler(this.mnuRun_Click);
            // btnStop
            this.btnStop.Location = new System.Drawing.Point(108, 3);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(90, 24);
            this.btnStop.Text = "■ Arrêter";
            this.btnStop.Click += new System.EventHandler(this.mnuStop_Click);
            // btnClearOutput
            this.btnClearOutput.Location = new System.Drawing.Point(202, 3);
            this.btnClearOutput.Name = "btnClearOutput";
            this.btnClearOutput.Size = new System.Drawing.Size(80, 24);
            this.btnClearOutput.Text = "Effacer";
            this.btnClearOutput.Click += new System.EventHandler(this.mnuClearOutput_Click);
            // lblOutputTitle
            this.lblOutputTitle.AutoSize = true;
            this.lblOutputTitle.Location = new System.Drawing.Point(300, 7);
            this.lblOutputTitle.Name = "lblOutputTitle";
            this.lblOutputTitle.Size = new System.Drawing.Size(150, 15);
            this.lblOutputTitle.Text = "Sortie du programme (double-clic sur une erreur pour y aller)";
            // btnHideOutput
            this.btnHideOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHideOutput.Location = new System.Drawing.Point(1068, 3);
            this.btnHideOutput.Name = "btnHideOutput";
            this.btnHideOutput.Size = new System.Drawing.Size(28, 24);
            this.btnHideOutput.Text = "✕";
            this.btnHideOutput.Click += new System.EventHandler(this.btnHideOutput_Click);
            // rtbOutput
            this.rtbOutput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbOutput.DetectUrls = false;
            this.rtbOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbOutput.Font = new System.Drawing.Font("Consolas", 10F);
            this.rtbOutput.HideSelection = false;
            this.rtbOutput.Name = "rtbOutput";
            this.rtbOutput.ReadOnly = true;
            this.rtbOutput.Size = new System.Drawing.Size(1100, 137);
            this.rtbOutput.TabIndex = 1;
            this.rtbOutput.WordWrap = false;
            this.rtbOutput.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.rtbOutput_MouseDoubleClick);
            // txtStdin
            this.txtStdin.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtStdin.Font = new System.Drawing.Font("Consolas", 10F);
            this.txtStdin.Name = "txtStdin";
            this.txtStdin.PlaceholderText = "Entrée standard du programme — Entrée pour envoyer une ligne";
            this.txtStdin.Size = new System.Drawing.Size(1100, 23);
            this.txtStdin.TabIndex = 2;
            this.txtStdin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtStdin_KeyDown);
            // statusStrip
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.lblSpring, this.lblPos, this.lblSel, this.lblLines, this.lblEol });
            this.statusStrip.Location = new System.Drawing.Point(0, 698);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1100, 22);
            this.statusStrip.TabIndex = 2;
            // lblSpring
            this.lblSpring.Name = "lblSpring";
            this.lblSpring.Spring = true;
            this.lblSpring.Text = "";
            // lblPos
            this.lblPos.Name = "lblPos";
            this.lblPos.AutoSize = false;
            this.lblPos.Size = new System.Drawing.Size(130, 17);
            this.lblPos.Text = "";
            this.lblPos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // lblSel
            this.lblSel.Name = "lblSel";
            this.lblSel.AutoSize = false;
            this.lblSel.Size = new System.Drawing.Size(90, 17);
            this.lblSel.Text = "";
            this.lblSel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // lblLines
            this.lblLines.Name = "lblLines";
            this.lblLines.AutoSize = false;
            this.lblLines.Size = new System.Drawing.Size(100, 17);
            this.lblLines.Text = "";
            this.lblLines.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // lblEol
            this.lblEol.Name = "lblEol";
            this.lblEol.AutoSize = false;
            this.lblEol.Size = new System.Drawing.Size(110, 17);
            this.lblEol.Text = "";
            this.lblEol.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // MainForm
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 720);
            this.Controls.Add(this.splitLeft);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Éditeur Forth";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
            this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
            this.splitLeft.Panel1.ResumeLayout(false);
            this.splitLeft.Panel2.ResumeLayout(false);
            this.splitOuter.Panel1.ResumeLayout(false);
            this.splitOuter.Panel2.ResumeLayout(false);
            this.splitInner.Panel1.ResumeLayout(false);
            this.splitInner.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitOuter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitInner)).EndInit();
            this.splitLeft.ResumeLayout(false);
            this.pnlProject.ResumeLayout(false);
            this.pnlProjectBar.ResumeLayout(false);
            this.ctxProject.ResumeLayout(false);
            this.splitOuter.ResumeLayout(false);
            this.splitInner.ResumeLayout(false);
            this.pnlOutline.ResumeLayout(false);
            this.pnlOutput.ResumeLayout(false);
            this.pnlOutputBar.ResumeLayout(false);
            this.menuStrip.ResumeLayout(false);
            this.statusStrip.ResumeLayout(false);
            this.ctxEditor.ResumeLayout(false);
            this.pnlOutline.PerformLayout();
            this.pnlProject.PerformLayout();
            this.pnlProjectBar.PerformLayout();
            this.pnlOutput.PerformLayout();
            this.pnlOutputBar.PerformLayout();
            this.menuStrip.PerformLayout();
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ContextMenuStrip ctxEditor;
        private System.Windows.Forms.SplitContainer splitOuter;
        private System.Windows.Forms.SplitContainer splitInner;
        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.Panel pnlOutline;
        private System.Windows.Forms.Label lblOutline;
        private System.Windows.Forms.TextBox txtOutlineFilter;
        private System.Windows.Forms.ListBox lstOutline;
        private System.Windows.Forms.Panel pnlOutput;
        private System.Windows.Forms.Panel pnlOutputBar;
        private System.Windows.Forms.Label lblOutputTitle;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnClearOutput;
        private System.Windows.Forms.Button btnHideOutput;
        private System.Windows.Forms.RichTextBox rtbOutput;
        private System.Windows.Forms.TextBox txtStdin;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuView;
        private System.Windows.Forms.ToolStripMenuItem mnuRunMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuSettingsMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuTheme;
        private System.Windows.Forms.ToolStripMenuItem mnuFold;
        private System.Windows.Forms.ToolStripMenuItem mnuNew;
        private System.Windows.Forms.ToolStripMenuItem mnuOpen;
        private System.Windows.Forms.ToolStripMenuItem mnuRecent;
        private System.Windows.Forms.ToolStripMenuItem mnuSave;
        private System.Windows.Forms.ToolStripMenuItem mnuSaveAs;
        private System.Windows.Forms.ToolStripMenuItem mnuPrint;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuQuit;
        private System.Windows.Forms.ToolStripMenuItem mnuUndo;
        private System.Windows.Forms.ToolStripMenuItem mnuRedo;
        private System.Windows.Forms.ToolStripMenuItem mnuCut;
        private System.Windows.Forms.ToolStripMenuItem mnuCopy;
        private System.Windows.Forms.ToolStripMenuItem mnuPaste;
        private System.Windows.Forms.ToolStripMenuItem mnuSelectAll;
        private System.Windows.Forms.ToolStripMenuItem mnuFind;
        private System.Windows.Forms.ToolStripMenuItem mnuFindNext;
        private System.Windows.Forms.ToolStripMenuItem mnuFindPrev;
        private System.Windows.Forms.ToolStripMenuItem mnuReplace;
        private System.Windows.Forms.ToolStripMenuItem mnuGoTo;
        private System.Windows.Forms.ToolStripMenuItem mnuReloadSyntax;
        private System.Windows.Forms.ToolStripMenuItem mnuEditSyntax;
        private System.Windows.Forms.ToolStripMenuItem mnuThemeDark;
        private System.Windows.Forms.ToolStripMenuItem mnuThemeLight;
        private System.Windows.Forms.ToolStripMenuItem mnuZoomIn;
        private System.Windows.Forms.ToolStripMenuItem mnuZoomOut;
        private System.Windows.Forms.ToolStripMenuItem mnuZoomReset;
        private System.Windows.Forms.ToolStripMenuItem mnuShowOutline;
        private System.Windows.Forms.ToolStripMenuItem mnuShowOutput;
        private System.Windows.Forms.ToolStripMenuItem mnuFoldToggle;
        private System.Windows.Forms.ToolStripMenuItem mnuFoldAll;
        private System.Windows.Forms.ToolStripMenuItem mnuUnfoldAll;
        private System.Windows.Forms.ToolStripMenuItem mnuRestoreSession;
        private System.Windows.Forms.ToolStripMenuItem mnuRun;
        private System.Windows.Forms.ToolStripMenuItem mnuStop;
        private System.Windows.Forms.ToolStripMenuItem mnuClearOutput;
        private System.Windows.Forms.ToolStripMenuItem mnuForthSettings;
        private System.Windows.Forms.ToolStripMenuItem mnuAutoComplete;
        private System.Windows.Forms.ToolStripMenuItem ctxCut;
        private System.Windows.Forms.ToolStripMenuItem ctxCopy;
        private System.Windows.Forms.ToolStripMenuItem ctxPaste;
        private System.Windows.Forms.ToolStripMenuItem ctxSelectAll;
        private System.Windows.Forms.ToolStripSeparator sepFile1;
        private System.Windows.Forms.ToolStripSeparator sepFile2;
        private System.Windows.Forms.ToolStripSeparator sepFile3;
        private System.Windows.Forms.ToolStripSeparator sepFile4;
        private System.Windows.Forms.ToolStripSeparator sepEdit1;
        private System.Windows.Forms.ToolStripSeparator sepEdit2;
        private System.Windows.Forms.ToolStripSeparator sepEdit3;
        private System.Windows.Forms.ToolStripSeparator sepView1;
        private System.Windows.Forms.ToolStripSeparator sepView2;
        private System.Windows.Forms.ToolStripSeparator sepView3;
        private System.Windows.Forms.ToolStripSeparator sepCtx;
        private System.Windows.Forms.ToolStripStatusLabel lblSpring;
        private System.Windows.Forms.ToolStripStatusLabel lblPos;
        private System.Windows.Forms.ToolStripStatusLabel lblSel;
        private System.Windows.Forms.ToolStripStatusLabel lblLines;
        private System.Windows.Forms.ToolStripStatusLabel lblEol;
        private System.Windows.Forms.ToolStripMenuItem mnuToolsMenu;
        private System.Windows.Forms.ToolStripMenuItem mnuTerminal;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenSyntaxFolder;
        private System.Windows.Forms.SplitContainer splitLeft;
        private System.Windows.Forms.Panel pnlProject;
        private System.Windows.Forms.Label lblProject;
        private System.Windows.Forms.Panel pnlProjectBar;
        private System.Windows.Forms.ComboBox cboProjectFolder;
        private System.Windows.Forms.Button btnProjectBrowse;
        private System.Windows.Forms.ComboBox cboProjectFilter;
        private System.Windows.Forms.TextBox txtProjectFilter;
        private System.Windows.Forms.TreeView tvProject;
        private System.Windows.Forms.ContextMenuStrip ctxProject;
        private System.Windows.Forms.ToolStripMenuItem ctxProjOpen;
        private System.Windows.Forms.ToolStripMenuItem ctxProjNewFile;
        private System.Windows.Forms.ToolStripSeparator sepProj;
        private System.Windows.Forms.ToolStripMenuItem ctxProjExplorer;
        private System.Windows.Forms.ToolStripMenuItem ctxProjRefresh;
        private System.Windows.Forms.CheckBox chkOutlineDefsOnly;
        private System.Windows.Forms.ToolStripMenuItem mnuOpenFolder;
        private System.Windows.Forms.ToolStripMenuItem mnuShowProject;
    }
}
